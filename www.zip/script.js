/**
 * Created by Karim on 09.02.2015.
 */
var teams = new Array();
function Team(firstPlayer,secondPlayer)
{
    this.firstPlayer = firstPlayer;
    this.secondPlayer = secondPlayer;
}
Team.prototype = function getName()
{
    return
}
function Player(login,name,surname,rank)
{
    this.login = login;
    this.playerName = name;
    this.playerSurname = surname;
    this.rank = rank;
}
function show(state)
{
    document.getElementById("passHelp").style.visibility = 'hidden';
    document.getElementById('window').style.display = state;
    document.getElementById('wrap').style.display = state;
}

function Tournament()
{
    this.players = new Array();
    this.rounds = new Array();
}
function Tournaments()
{
    this.tournaments = new Array();
}
function generateRound()
{
    var numOfRounds =  parseInt(document.getElementById("numOfRounds").value);
/*    var num = parseInt(rounds.childNodes[3].value);*/
    var rounds = document.getElementById("rounds");
    rounds.innerHTML="";
    for(var i = 0 ; i<  numOfRounds ;i++)
    {
        var elem = document.createElement("select");
        elem.innerHTML = "<option>Пункт 1</option><br/><option>Пункт 2</option>";
        elem.style.marginLeft = "10px";
        rounds.appendChild(document.createElement("br"));
        var strNum = i+1;
        if(i<9)
            strNum = "0"+strNum;
        rounds.appendChild(document.createTextNode(strNum+"-й раунд:"));
        rounds.appendChild(elem);

        var button = document.createElement("input");
        button.type = "button";
        button.value = "+";
        button.name = i+"addPlayer";
        button.onclick = function fun(){ show('block'); }
        rounds.appendChild(button);
    }

}

/*
var txt = document.createElement("p");
txt.innerHTML = i+1+"ый Раунд:";*/
