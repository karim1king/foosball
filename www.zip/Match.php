<?php
/**
 * Created by PhpStorm.
 * User: Karim
 * Date: 13.02.2015
 * Time: 21:45
 */

class Match
{
    public  $firstTeam;
    public  $secondTeam;
    public  $firstTeamScore;
    public $secondTeamScore;
    public $round;
    public $id;
    public function __construct($firstTeam,$secondTeam,$firstTeamScore,$secondTeamScore,$round)
    {
        $this->firstTeam = $firstTeam;
        $this->secondTeam = $secondTeam;
        $this->firstTeamScore = $firstTeamScore;
        $this->secondTeamScore = $secondTeamScore;
        $this->round = $round;
    }
    public function __toString()
    {
        return ($this->firstTeam."  $this->firstTeamScore:$this->secondTeamScore  ".$this->secondTeam) ;
    }


} 