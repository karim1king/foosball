<?php session_start();?>
<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <title></title>
    <link type="text/css" rel="stylesheet" href="adminStyle.css"/>
    <?php
        require_once "Player.php";
        $matchTable = $_GET['turname']."_matches";
        $teamTable = $_GET['turname']."_teams";
         $teamId = $_GET['id'];
        require_once "mysqli_MY.php"; $mysqli= connectMysqli();
        $result = $mysqli->query("SELECT * FROM $teamTable WHERE id=$teamId");
        $team = $result->fetch_assoc();
        $firstPlayer = Player::getPlayerNameById($team['idfplayer'],$mysqli);
        $secondPlayer = Player::getPlayerNameById($team['idsplayer'],$mysqli);
        $result = $mysqli->query("SELECT * FROM $matchTable WHERE fteam=$teamId OR steam=$teamId");
        $win=0;
        $lost=0;
        $scored=0;
        $missed=0;
        $played=0;

        while($row = $result->fetch_assoc())
        {
            if($row['fteam']==$teamId)
            {
                if( $row['fscore'] != null)
                {
                    $played++;
                    $scored += $row['fscore'];
                    $missed   += $row['sscore'];
                    if($row['fscore']==$row['sscore'])
                        continue;
                    if($row['fscore']>$row['sscore'])
                    {
                        $win++;
                    }
                    else
                    {
                        $lost++;
                    }
                }
            }
            else
            {
                if( $row['sscore'] != null)
                {
                    $scored += $row['sscore'];
                    $missed += $row['fscore'];
                    if ($row['fscore'] == $row['sscore'])
                        continue;
                    if ($row['sscore'] > $row['fscore']) {
                        $win++;
                    } else {
                        $lost++;
                    }
                }
            }
        }
        $mysqli->close();
    ?>

    <script type="text/javascript">

    </script>
</head>
<body>
<div id="main">
    <?php
    include 'menu.php';
    ?>
    <div class="title">
        <p>О команде</p>
    </div>

    <div id="forma" >
        <form action="generateT.php" method="post">

            <hr/>
            <div>
                <p class="leg">Команда:  <?php echo $team['teamName'] ?></p>
                <div class="block" >
                    <?
                        $idfplayer = $team['idfplayer'];
                    ?>
                    <p>Первый игрок : <?echo $firstPlayer?></p>
                    <p>Второй игрок : <? echo $secondPlayer?></p>
                    <hr/>
                    <p>кол-во сыгранных игр : <? echo $played?></p>
                    <p>кол-во побед : <?echo $win?></p>
                    <p>кол-во поражений : <? echo$lost?></p>
                    <p>забитые : <?echo $scored?></p>
                    <p>пропущенные голы : <?echo $missed?></p>
                </div>
            </div>

        </form>
    </div>
</div>
</body>
</html>
