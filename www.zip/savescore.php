<?php
require_once "mysqli_MY.php"; $mysqli= connectMysqli();
    $turId = $_POST['turname'];
    $state = $_POST['turState'];
    $mysqli->query("UPDATE turtable SET state ='$state' WHERE id='$turId'");

    $type = $_GET['turType'];
    $matchTable='';
    if($type==1)
    {
        $matchTable = $_POST['turname'] . "_matches";

    }
    else
    {
        $matchTable = $_POST['turname'] . "_play_off";
    }

    foreach ($_POST as $key => $value)
    {
        if ($key != "turname")
        {
            if (is_array($value))
            {
                if($key[0]=='p')
                {
                    $id = substr($key,1);
                    $fteam = $value[0];
                    $steam = $value[1];
                    $mysqli->query("UPDATE $matchTable  SET fteam = $fteam,steam = $steam WHERE id=$id");
                }
                else
                {
                    $fscore = $value[0];
                    $sscore = $value[1];
                    $mysqli->query("UPDATE $matchTable  SET fscore = $fscore,sscore = $sscore WHERE id=$key");
                }
            }
        }
    }
$mysqli->close();
    header("location:turlistedit.php");
