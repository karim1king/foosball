<?php
    $tur = $_GET['turname'];
    $match_Table = $tur."_matches";
    $team_Table = $tur."_teams";
    require_once "mysqli_MY.php"; $mysqli= connectMysqli();
    $mysqli->query("Delete FROM turtable WHERE id=$tur");
    $mysqli->query("DROP TABLE $match_Table");
    $mysqli->query("DROP TABLE $team_Table");
    $mysqli->close();
    header("location: turlistedit.php");