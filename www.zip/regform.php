<?php session_start() ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>111111</title>
<!--    <script type="text/javascript" src="script.js"> </script>-->
    <script type="text/javascript" src="validate.js"> </script>
    <link type="text/css" rel="stylesheet" href="adminStyle.css"/>
    <link type="text/css" rel="stylesheet" href="regStyle.css"/>


</head>
<body>
<div id="main">
    <?php
         include 'menu.php';
    ?>
    <div class="title">
        <p>Регистрация</p>
    </div>

    <div id="forma">
        <form action="reg.php" method="post">
            <hr/>
            <div class="regBlock">

                <label>Логин:</label><br/>
                <input type="text" name="login"onblur="validateNonEmpty(this, document.getElementById('login_help'))"/>
                <span id="login_help" class="help">
                        <?php
                            if($_REQUEST['error'] == 2 || $_REQUEST['error'] == 3)
                            echo "Пользователь с таким логином уже существует!!";
                         ?>
                </span>
                <label>Имя:</label><br/>
                <input type="text" name="name" onblur="validateNonEmpty(this, document.getElementById('name_help'))"/>
                <span id="name_help" class="help"></span>

                <label>Фамилия:</label><br/>
                <input type="text" name="surname" onblur="validateNonEmpty(this, document.getElementById('surname_help'))"/>
                <span id="surname_help" class="help"></span>

                <label>E-mail:</label><br/>
                <input type="text" name="email" onblur="validateEmail(this, document.getElementById('email_help'))"/>
                <span id="email_help" class="help">
                    <?php
                    if($_REQUEST['error'] == 1 || $_REQUEST['error'] == 3)
                      echo "Пользователь с таким адресом уже существует!!";
                     ?>
                </span>

                <label>Пароль:</label><br/>
                <input type="password" name="password1" onblur="validateLength(6,16,this, document.getElementById('password_help1'))"/>
                <span id="password_help1" class="help"></span>
                <label>Повторите пароль:</label><br/>
                <input type="password" name="password2" onblur="validateLength(6,16,this, document.getElementById('password_help2'))"/>
                <span id="password_help2" class="help"></span><br/>
                <input class="button" type="submit"  value="Регистрация""/>
            </div>
        </form>
    </div>
</div>
</body>
</html>