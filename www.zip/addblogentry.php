<?php
$filename = "news/blog.xml";
if (file_exists($filename))
{
  // Load the blog entries from the XML file
  $rawBlog = file_get_contents($filename);
}
else
{
  // Create an empty XML document
  $rawBlog = "<?xml version=\"1.0\" encoding=\"utf-8\" ?>";
  $rawBlog .= "<blog><title>Новасти ностольного чемпионата</title>";
  $rawBlog .= "<author>Admin Karim</author><entries></entries></blog>";
}
$xml = new SimpleXmlElement($rawBlog);

// Add the new blog entry as a child node
$entry = $xml->entries->addChild("entry");
$entry->addChild("date", $_POST["date"]);
$entry->addChild("body", stripslashes($_POST["body"]));

/*if($_FILES["filename"]["size"] > 1024*3*1024)
{
    echo ("Размер файла превышает три мегабайта");
    exit;
}*/

// Проверяем загружен ли файл
$finalPath;
if(is_uploaded_file($_FILES["filename"]["tmp_name"]))
{
    $finalPath = "news/".uniqid().$_FILES["filename"]["name"];
    move_uploaded_file($_FILES["filename"]["tmp_name"], $finalPath);
}

if (isset($finalPath))
  $entry->addChild("image", $finalPath);

// Write the entire blog to the file
$file = fopen($filename, 'w');
fwrite($file, $xml->asXML());
fclose($file);
header("location:turlistedit.php");

