<?php

function connectMysqli()
{
/*    return new mysqli('localhost','admin','','u441506039_reg');*/
    return new mysqli('a132670.mysql.mchost.ru','a132670_1','k123456789','a132670_1');
}
